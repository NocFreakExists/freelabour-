# Model package (.zip)
- `model.json`: TF.js layers-model topology + weight manifest (one shard, `weights.bin`)
- `weights.bin`: raw weights
- `metadata.json`: schemaVersion(1), name, version, labels (ordered), sampleRate, windowSec, hopSec, features, normalization, architecture, inputShape, trainConfig, metrics, tfjsVersion, exportDate
- `checksums.json`: SHA-256 of the three files above
Import rejects: non-zip, extra files, missing files, checksum mismatch, bad schema, label/output-size mismatch, oversize files (>100 MB).
