# Privacy
Sound Lab runs entirely in your browser. Your audio, datasets and models are stored only on this device (IndexedDB). Nothing is uploaded; there are no accounts, analytics, telemetry, CDNs or remote services. Data leaves the device only when you press an export button. Clearing site data deletes your projects: export backups first.
