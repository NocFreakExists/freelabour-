// CI gate: fail if source contains http(s):// (outside comments) or network APIs aimed at remote hosts.
import { readdirSync, statSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
const walk = (d) => readdirSync(d).flatMap((f) => { const p = join(d, f); return statSync(p).isDirectory() ? walk(p) : [p]; });
let bad = 0;
for (const f of [...walk('src'), ...walk('public').filter((p) => /\.(js|html|webmanifest)$/.test(p) && !p.includes('vendor')), 'index.html', 'trainer/index.html', 'lab/index.html', 'listen/index.html']) {
  readFileSync(f, 'utf8').split('\n').forEach((line, i) => {
    const code = line.replace(/\/\/.*$/, '');
    if (/https?:\/\//.test(code) || /\b(XMLHttpRequest|WebSocket|EventSource|sendBeacon)\b/.test(code)) { console.error(`${f}:${i + 1}: ${line.trim()}`); bad++; }
  });
}
if (bad) { console.error(`FAIL: ${bad} suspicious network reference(s)`); process.exit(1); }
console.log('check-no-network: OK');
