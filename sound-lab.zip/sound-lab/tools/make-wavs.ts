// npm run synth  ->  writes synthetic-dataset/<class>/<file>.wav
import { mkdirSync, writeFileSync } from 'node:fs';
import { generateToneNoise, encodeWav } from '../src/core/synth';
for (const c of generateToneNoise(20, 3, 16000, 42)) {
  mkdirSync(`synthetic-dataset/${c.label}`, { recursive: true });
  writeFileSync(`synthetic-dataset/${c.label}/${c.name}`, encodeWav(c.data, 16000));
}
console.log('wrote synthetic-dataset/');
