// Copies TF.js WASM binaries into public/vendor so no CDN is ever used.
import { readdirSync, copyFileSync, mkdirSync, existsSync } from 'node:fs';
const src = 'node_modules/@tensorflow/tfjs-backend-wasm/dist';
if (!existsSync(src)) { console.log('copy-wasm: package not installed yet, skipping'); process.exit(0); }
mkdirSync('public/vendor', { recursive: true });
for (const f of readdirSync(src).filter((f) => f.endsWith('.wasm'))) copyFileSync(`${src}/${f}`, `public/vendor/${f}`);
console.log('copy-wasm: done');
