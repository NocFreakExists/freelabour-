# Third-party licenses (fill in after `npm install`)
Run: `npx license-checker --production --csv > LICENSES/third-party.csv`
Direct runtime deps: @tensorflow/tfjs (Apache-2.0), @tensorflow/tfjs-backend-wasm (Apache-2.0), fflate (MIT).
Copy each package's LICENSE file here before shipping. No pretrained weights are bundled, so fine-tune mode is intentionally absent.
