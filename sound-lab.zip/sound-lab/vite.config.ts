import { defineConfig, Plugin } from 'vite';
import { resolve, join, relative } from 'node:path';
import { readdirSync, statSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

function walk(dir: string): string[] {
  return readdirSync(dir).flatMap((f) => {
    const p = join(dir, f);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });
}

// After build: list every emitted file, write precache.json, inject into sw.js.
function precachePlugin(): Plugin {
  let outDir = 'dist';
  return {
    name: 'precache',
    apply: 'build',
    configResolved(c) { outDir = resolve(c.root, c.build.outDir); },
    closeBundle() {
      const files = walk(outDir).map((p) => '/' + relative(outDir, p).split('\\').join('/'))
        .filter((u) => u !== '/sw.js' && u !== '/precache.json');
      const hash = createHash('sha256');
      for (const f of files) hash.update(readFileSync(join(outDir, f)));
      const version = hash.digest('hex').slice(0, 12);
      const assets = ['/trainer/', '/lab/', '/listen/', '/', ...files];
      writeFileSync(join(outDir, 'precache.json'), JSON.stringify({ version, assets }));
      const swPath = join(outDir, 'sw.js');
      writeFileSync(swPath, readFileSync(swPath, 'utf8')
        .replace('__VERSION__', version).replace('__ASSETS__', JSON.stringify(assets)));
    },
  };
}

export default defineConfig({
  build: {
    target: 'es2022',
    rollupOptions: {
      input: {
        home: resolve(__dirname, 'index.html'),
        trainer: resolve(__dirname, 'trainer/index.html'),
        lab: resolve(__dirname, 'lab/index.html'),
        listen: resolve(__dirname, 'listen/index.html'),
      },
    },
  },
  plugins: [precachePlugin()],
  test: { environment: 'node', include: ['tests/unit/**/*.test.ts'], testTimeout: 180000 },
});
