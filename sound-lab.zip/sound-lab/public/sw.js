const VERSION = '__VERSION__';
const CACHE = 'soundlab-' + VERSION;
const ASSETS = __ASSETS__;

// addAll is atomic: a partial install fails and the browser retries it.
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)));
});
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith('soundlab-') && k !== CACHE) await caches.delete(k);
    await self.clients.claim();
  })());
});
self.addEventListener('message', (e) => {
  if (e.data === 'SKIP_WAITING') self.skipWaiting();
  if (e.data === 'CLEAR_CACHE') e.waitUntil(caches.keys().then((ks) => Promise.all(ks.map((k) => caches.delete(k)))));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== self.location.origin) return;
  let path = url.pathname;
  if (path.endsWith('/')) path += 'index.html';
  else if (!path.split('/').pop().includes('.')) path += '/index.html';
  e.respondWith(caches.match(path, { ignoreSearch: true }).then((r) => r || fetch(e.request)));
});
