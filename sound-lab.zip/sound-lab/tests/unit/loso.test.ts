import { describe, it, expect } from 'vitest';
import { DEFAULT_CONFIG as C, extractWindow, splitWindows } from '../../src/core/audio/features';
import { DEFAULT_TRAIN, Item, leaveOneSongOut, wilson } from '../../src/core/model/train';
import { generateToneNoise } from '../../src/core/synth';

describe('leave-one-song-out', () => {
  it('runs one fold per held-out song and scores above chance on tone-vs-noise', async () => {
    const items: Item[] = generateToneNoise(6, 3, 16000, 5).flatMap((c) =>
      splitWindows(c.data, C).map((w) => ({ x: extractWindow(w, C).data, w: new Float32Array(0), y: c.label === 'tone' ? 0 : 1, rec: c.name })));
    const r = await leaveOneSongOut(items, ['tone', 'noise'], C, { ...DEFAULT_TRAIN, epochs: 6, batchSize: 8, augment: { ...DEFAULT_TRAIN.augment, copies: 0 } },
      { onFold: () => {}, signal: new AbortController().signal }, 3);
    expect(r.cancelled).toBe(false);
    expect(r.results.length).toBe(4); // 12 songs, every 3rd
    const acc = r.results.filter((x) => x.truth === x.pred).length / r.results.length;
    console.log('LOSO song accuracy', acc);
    expect(acc).toBeGreaterThanOrEqual(0.75);
  });
  it('wilson interval is sane', () => { const [lo, hi] = wilson(12, 24); expect(lo).toBeLessThan(0.5); expect(hi).toBeGreaterThan(0.5); });
});
