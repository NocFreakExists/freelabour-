import { describe, it, expect } from 'vitest';
import { DEFAULT_CONFIG as C, extractWindow, splitWindows, inputShape, fft, resample } from '../../src/core/audio/features';
import { generateToneNoise } from '../../src/core/synth';

describe('feature pipeline', () => {
  it('has the declared shape and finite values', () => {
    const f = extractWindow(generateToneNoise(1)[0].data.slice(0, 16000), C);
    expect(f.data.length).toBe(inputShape(C)[0] * inputShape(C)[1]);
    expect(f.data.every(Number.isFinite)).toBe(true);
  });
  it('training path and inference path give identical features', () => {
    const clip = generateToneNoise(1)[0].data;
    const fromTraining = splitWindows(clip, C).map((w) => extractWindow(w, C).data);
    // Inference path: Listener feeds one window at a time into the same function
    const fromInference = splitWindows(clip, C).map((w) => extractWindow(Float32Array.from(w), C).data);
    fromTraining.forEach((a, i) => expect(Math.max(...a.map((v, k) => Math.abs(v - fromInference[i][k])))).toBe(0));
  });
  it('detects silence and clipping', () => {
    expect(extractWindow(new Float32Array(16000), C).silent).toBe(true);
    expect(extractWindow(new Float32Array(16000).fill(1), C).clipped).toBe(true);
  });
  it('FFT puts a pure tone in the right bin', () => {
    const n = 512, re = new Float64Array(n).map((_, i) => Math.sin((2 * Math.PI * 32 * i) / n)), im = new Float64Array(n);
    fft(re, im);
    const mag = re.map((v, i) => Math.hypot(v, im[i])).slice(0, 256);
    expect(mag.indexOf(Math.max(...mag))).toBe(32);
  });
  it('resamples 48k to 16k length', () => expect(resample(new Float32Array(48000), 48000, 16000).length).toBe(16000));
  it('pads short clips to one window', () => expect(splitWindows(new Float32Array(100), C).length).toBe(1));
});
