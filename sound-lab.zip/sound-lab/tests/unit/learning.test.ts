import { describe, it, expect } from 'vitest';
import { DEFAULT_CONFIG as C, extractWindow, splitWindows, inputShape } from '../../src/core/audio/features';
import { DEFAULT_TRAIN, Item, evaluate, splitByRecording, train } from '../../src/core/model/train';
import { predictFeatures } from '../../src/core/model/cnn';
import { exportPackage, importPackage } from '../../src/core/package/pkg';
import { generateToneNoise } from '../../src/core/synth';
import type { ModelMeta } from '../../src/core/types';

const labels = ['tone', 'noise'];
function items(): Item[] {
  return generateToneNoise(10, 3, 16000, 3).flatMap((c) =>
    splitWindows(c.data, C).map((w) => ({ x: extractWindow(w, C).data, w, y: labels.indexOf(c.label), rec: c.name })));
}
const meta = (m: object = {}): ModelMeta => ({ schemaVersion: 1, name: 't', version: 1, labels, sampleRate: 16000, windowSec: 1, hopSec: .5,
  features: C, normalization: 'peak', architecture: 'cnn', inputShape: inputShape(C), trainConfig: {}, metrics: {}, tfjsVersion: 'x', exportDate: '', ...m });

describe('learning', () => {
  it('splits by recording with no leakage', () => {
    const s = splitByRecording(items(), 2, 0.2, 0.2, 1);
    const ids = (a: Item[]) => new Set(a.map((i) => i.rec));
    const [tr, va, te] = [ids(s.train), ids(s.val), ids(s.test)];
    for (const [a, b] of [[tr, va], [tr, te], [va, te]] as const) expect([...a].filter((x) => b.has(x))).toEqual([]);
    expect(s.hasIndependentTest).toBe(true);
  });
  it('learns tone-vs-noise above chance and above the majority baseline; export/reload matches', async () => {
    const s = splitByRecording(items(), 2, 0.2, 0.2, 1);
    const model = await train(s, labels, C, { ...DEFAULT_TRAIN, epochs: 12, batchSize: 8 }, { onEpoch: () => {}, signal: new AbortController().signal });
    expect(model).not.toBeNull();
    const r = evaluate(model!, s.test, 2, C);
    const counts = [0, 1].map((k) => s.test.filter((i) => i.y === k).length);
    const majority = Math.max(...counts) / s.test.length;
    console.log('held-out accuracy', r.accuracy, 'majority baseline', majority, 'n', r.n);
    expect(r.accuracy).toBeGreaterThanOrEqual(0.9);
    expect(r.accuracy).toBeGreaterThan(majority + 0.2);

    const shape: [number, number] = [inputShape(C)[0], inputShape(C)[1]];
    const xs = s.test.slice(0, 10).map((i) => i.x), before = predictFeatures(model!, xs, shape);
    const { model: m2 } = await importPackage(await exportPackage(model!, meta()));
    const after = predictFeatures(m2, xs, shape);
    const diff = Math.max(...before.flatMap((p, i) => [...p].map((v, k) => Math.abs(v - after[i][k]))));
    console.log('max export/reload diff', diff);
    expect(diff).toBeLessThan(1e-5);
  });
  it('cancel returns null and leaves no model', async () => {
    const ac = new AbortController(); ac.abort();
    const m = await train(splitByRecording(items(), 2, 0.2, 0.2, 1), labels, C, { ...DEFAULT_TRAIN, epochs: 5 }, { onEpoch: () => {}, signal: ac.signal });
    expect(m).toBeNull();
  });
  it('rejects tampered and malformed packages', async () => {
    const s = splitByRecording(items(), 2, 0.2, 0.2, 1);
    const model = (await train(s, labels, C, { ...DEFAULT_TRAIN, epochs: 1 }, { onEpoch: () => {}, signal: new AbortController().signal }))!;
    const zip = await exportPackage(model, meta());
    const { unzipSync, zipSync, strToU8 } = await import('fflate');
    const f = unzipSync(zip); f['metadata.json'] = strToU8(JSON.stringify(meta({ name: 'evil' })));
    await expect(importPackage(zipSync(f))).rejects.toThrow(/Checksum mismatch/);
    await expect(importPackage(new Uint8Array([1, 2, 3]))).rejects.toThrow(/valid zip/);
  });
});
