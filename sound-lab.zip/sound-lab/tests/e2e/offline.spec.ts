import { test, expect } from '@playwright/test';
test('installs, then runs with the network off and makes zero external requests', async ({ page, context }) => {
  const external: string[] = [];
  page.on('request', (r) => { if (!r.url().startsWith('http://127.0.0.1:4173')) external.push(r.url()); });
  await page.goto('/trainer/');
  await page.evaluate(() => navigator.serviceWorker.ready);
  await expect(page.getByRole('status')).toContainText('Offline-ready', { timeout: 30000 });
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Trainer Studio' })).toBeVisible();
  await page.getByRole('button', { name: /synthetic/ }).click();
  await expect(page.getByText('tone (12 samples)')).toBeVisible();
  expect(external).toEqual([]);
});
