# Sound Lab: offline audio classifier (Trainer, Lab, Listener)

STATUS: code written but NOT yet run. Nothing here is verified until you run the commands below and the tests pass.

## Run it on your PC
Requirements: Node.js 20+ and a Chromium-based browser or Firefox (needs internet only for `npm install`).

    npm install            # also copies the WASM binaries into public/vendor
    npm test               # unit tests (features parity, split leakage, learning, export/reload, tamper)
    npm run check:net      # fails on any http(s):// or network API in source
    npx playwright install chromium && npm run e2e   # offline end-to-end check
    npm run serve          # builds, then serves http://127.0.0.1:4173

Open http://127.0.0.1:4173/ and wait for "Offline-ready" in the footer. After that you can disconnect.
Use `npm run serve`, not `npm run dev`: the service worker is registered in production builds only.
Do not open the files from file:// because service workers, microphone access and ES modules are blocked or unreliable there.
After the first `npm install`, commit package-lock.json.

## Try it
1. /trainer/ -> "Load synthetic tone-vs-noise project" -> Train -> read the held-out results -> "Publish to library".
2. /lab/ -> pick the model -> upload a .wav -> label it -> see accuracy/confusion.
3. /listen/ -> pick the model -> Listen.

## Layout
    src/core/audio      features.ts (the ONE shared pipeline), decode.ts
    src/core/model      cnn.ts (build/predict), train.ts (split, augment, train, evaluate), infer.ts
    src/core/package    pkg.ts (zip export/import, checksums, validation)
    src/core/storage    db.ts (IndexedDB, quota errors, persist, usage)
    src/core/offline    register.ts (service worker, real cache verification)
    src/core/synth.ts   synthetic dataset generator   | tools/ build + CI scripts
    src/trainer|lab|listener  the three UIs           | public/sw.js service worker
    tests/unit, tests/e2e

## Known gaps (not implemented in this cut)
- Single project only: no project dashboard, rename/duplicate/import/export of whole projects, dataset export.
- No model version comparison/restore, no duplicate-sample detection, no loss/accuracy curve charts (the console shows numbers).
- Cancel works; pause/resume is unsupported and there is no checkpoint resume.
- Fine-tune mode is absent (no licensed pretrained weights bundled). Random init only.
- Recording uses MediaRecorder (webm/mp4); decoding support depends on the browser. WAV is the safe format.
- Weights are a single shard. No app icons in the manifest. LICENSES/ must be filled in after install.
- Safari/iOS may evict IndexedDB; export backups.
