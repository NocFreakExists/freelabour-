import * as tf from '@tensorflow/tfjs';
import { setWasmPaths } from '@tensorflow/tfjs-backend-wasm';
export { tf };
export async function initTF(): Promise<string> {
  setWasmPaths('/vendor/'); // wasm binaries are copied locally by tools/copy-wasm.mjs
  for (const b of ['webgl', 'wasm', 'cpu']) {
    try { if (await tf.setBackend(b)) { await tf.ready(); return tf.getBackend(); } } catch { /* try next */ }
  }
  throw new Error('No TensorFlow.js backend could start.');
}
