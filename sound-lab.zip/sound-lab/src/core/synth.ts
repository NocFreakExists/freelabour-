// Synthetic tone-vs-noise generator (used by tests, the Trainer demo button and tools/make-wavs.ts).
import { mulberry32 } from './model/train';
export interface SynthClip { label: string; name: string; data: Float32Array; }

export function generateToneNoise(perClass = 12, seconds = 3, sr = 16000, seed = 1): SynthClip[] {
  const rnd = mulberry32(seed), out: SynthClip[] = [];
  for (let i = 0; i < perClass; i++) {
    const f = 300 + rnd() * 1700, amp = 0.3 + rnd() * 0.5, n = seconds * sr;
    const tone = new Float32Array(n), noise = new Float32Array(n);
    for (let k = 0; k < n; k++) {
      tone[k] = amp * Math.sin((2 * Math.PI * f * k) / sr) + 0.02 * (rnd() - 0.5);
      noise[k] = amp * (rnd() * 2 - 1);
    }
    out.push({ label: 'tone', name: `tone_${i}.wav`, data: tone }, { label: 'noise', name: `noise_${i}.wav`, data: noise });
  }
  return out;
}

export function encodeWav(x: Float32Array, sr: number): Uint8Array {
  const buf = new ArrayBuffer(44 + x.length * 2), v = new DataView(buf);
  const s = (o: number, t: string) => [...t].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  s(0, 'RIFF'); v.setUint32(4, 36 + x.length * 2, true); s(8, 'WAVE'); s(12, 'fmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  s(36, 'data'); v.setUint32(40, x.length * 2, true);
  for (let i = 0; i < x.length; i++) v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, x[i])) * 32767, true);
  return new Uint8Array(buf);
}
