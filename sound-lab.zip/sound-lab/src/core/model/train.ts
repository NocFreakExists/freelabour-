import * as tf from '@tensorflow/tfjs';
import { buildModel, predictFeatures } from './cnn';
import { FeatureConfig, extractWindow, inputShape } from '../audio/features';

export function mulberry32(a: number) {
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

export interface Item { x: Float32Array; w: Float32Array; y: number; rec: string; }
export interface TrainConfig {
  epochs: number; batchSize: number; learningRate: number; seed: number; patience: number;
  classWeights: boolean; dropout: number;
  augment: { copies: number; noise: number; gain: number; shift: number };
}
export const DEFAULT_TRAIN: TrainConfig = {
  epochs: 30, batchSize: 16, learningRate: 0.003, seed: 1, patience: 6, classWeights: true, dropout: 0.3,
  augment: { copies: 1, noise: 0.01, gain: 0.3, shift: 0.1 },
};

// Split by SOURCE RECORDING per class so windows of one file never straddle sets.
export function splitByRecording(items: Item[], numClasses: number, valFrac: number, testFrac: number, seed: number) {
  const rnd = mulberry32(seed);
  const sets = { train: new Set<string>(), val: new Set<string>(), test: new Set<string>() };
  for (let c = 0; c < numClasses; c++) {
    const recs = [...new Set(items.filter((i) => i.y === c).map((i) => i.rec))];
    for (let i = recs.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [recs[i], recs[j]] = [recs[j], recs[i]]; }
    const n = recs.length;
    const nTest = testFrac > 0 && n >= 3 ? Math.max(1, Math.round(n * testFrac)) : 0;
    const nVal = valFrac > 0 && n - nTest >= 2 ? Math.max(1, Math.round(n * valFrac)) : 0;
    recs.forEach((r, i) => (i < nTest ? sets.test : i < nTest + nVal ? sets.val : sets.train).add(r));
  }
  const pick = (s: Set<string>) => items.filter((i) => s.has(i.rec));
  const out = { train: pick(sets.train), val: pick(sets.val), test: pick(sets.test) };
  return { ...out, hasIndependentTest: out.test.length > 0, hasValidation: out.val.length > 0 };
}

function augment(it: Item, a: TrainConfig['augment'], c: FeatureConfig, rnd: () => number): Item {
  const w = new Float32Array(it.w.length), shift = Math.round((rnd() * 2 - 1) * a.shift * w.length);
  const gain = 1 + (rnd() * 2 - 1) * a.gain;
  for (let i = 0; i < w.length; i++) {
    const s = i - shift;
    w[i] = (s >= 0 && s < w.length ? it.w[s] : 0) * gain + a.noise * (rnd() * 2 - 1);
  }
  return { ...it, w, x: extractWindow(w, c).data };
}

export interface EpochLog { epoch: number; loss: number; acc: number; valLoss?: number; valAcc?: number; seconds: number; }

export async function train(
  split: { train: Item[]; val: Item[] }, labels: string[], fc: FeatureConfig, cfg: TrainConfig,
  hooks: { onEpoch: (l: EpochLog) => void; signal: AbortSignal },
) {
  const K = labels.length, shape = inputShape(fc), rnd = mulberry32(cfg.seed + 7);
  let items = split.train;
  for (let k = 0; k < cfg.augment.copies; k++) items = items.concat(split.train.map((i) => augment(i, cfg.augment, fc, rnd)));
  const model = buildModel(K, shape, cfg.dropout, cfg.seed);
  model.compile({ optimizer: tf.train.adam(cfg.learningRate), loss: 'categoricalCrossentropy', metrics: ['accuracy'] });

  const mk = (arr: Item[]) => {
    const flat = new Float32Array(arr.length * shape[0] * shape[1]);
    arr.forEach((it, i) => flat.set(it.x, i * it.x.length));
    return [tf.tensor4d(flat, [arr.length, shape[0], shape[1], 1]),
            tf.oneHot(tf.tensor1d(arr.map((i) => i.y), 'int32'), K).toFloat()] as const;
  };
  const [xt, yt] = mk(items);
  const val = split.val.length ? mk(split.val) : null;
  const counts = new Array(K).fill(0); items.forEach((i) => counts[i.y]++);
  const classWeight = cfg.classWeights ? Object.fromEntries(counts.map((n, i) => [i, n ? items.length / (K * n) : 1])) : undefined;
  const t0 = performance.now();
  let cancelled = false;
  try {
    await model.fit(xt, yt, {
      epochs: cfg.epochs, batchSize: cfg.batchSize, shuffle: true, classWeight,
      validationData: val ? [val[0], val[1]] : undefined,
      callbacks: [
        { onEpochEnd: async (e: number, l?: tf.Logs) => {
            hooks.onEpoch({ epoch: e + 1, loss: l!.loss, acc: (l!.acc ?? l!.accuracy) as number,
              valLoss: l!.val_loss, valAcc: (l!.val_acc ?? l!.val_accuracy) as number | undefined,
              seconds: (performance.now() - t0) / 1000 });
            if (hooks.signal.aborted) { cancelled = true; model.stopTraining = true; }
          } },
        ...(val ? [tf.callbacks.earlyStopping({ monitor: 'val_loss', patience: cfg.patience })] : []),
      ],
    });
  } catch (e) {
    model.dispose();
    if (e instanceof Error && /memory|allocate/i.test(e.message))
      throw new Error('Out of memory. Reduce the batch size (try 8) or the augmentation copies, then retry.');
    throw e;
  } finally { xt.dispose(); yt.dispose(); val?.[0].dispose(); val?.[1].dispose(); }
  if (cancelled) { model.dispose(); return null; } // caller keeps the prior model untouched
  return model;
}

export function evaluate(model: tf.LayersModel, items: Item[], K: number, fc: FeatureConfig) {
  const shape = inputShape(fc), probs = predictFeatures(model, items.map((i) => i.x), [shape[0], shape[1]]);
  const confusion = Array.from({ length: K }, () => new Array(K).fill(0));
  probs.forEach((p, i) => confusion[items[i].y][p.indexOf(Math.max(...p))]++);
  const perClass = confusion.map((row, c) => {
    const tp = row[c], fn = row.reduce((a, b) => a + b, 0) - tp, fp = confusion.reduce((a, r) => a + r[c], 0) - tp;
    const precision = tp + fp ? tp / (tp + fp) : 0, recall = tp + fn ? tp / (tp + fn) : 0;
    return { precision, recall, f1: precision + recall ? (2 * precision * recall) / (precision + recall) : 0, support: tp + fn };
  });
  const correct = confusion.reduce((a, r, i) => a + r[i], 0);
  return { accuracy: items.length ? correct / items.length : 0, n: items.length, perClass, confusion };
}

export function wilson(k: number, n: number, z = 1.96): [number, number] {
  if (!n) return [0, 0];
  const p = k / n, d = 1 + (z * z) / n, c = p + (z * z) / (2 * n), m = z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n));
  return [(c - m) / d, (c + m) / d];
}

export interface SongResult { rec: string; truth: number; pred: number; }
// Train once per held-out song (every `stride`-th song). Reports SONG-level accuracy; produces no model.
export async function leaveOneSongOut(
  items: Item[], labels: string[], fc: FeatureConfig, cfg: TrainConfig,
  hooks: { onFold: (done: number, total: number, rec: string, ok: boolean | null) => void; signal: AbortSignal },
  stride = 1,
) {
  const K = labels.length, shape = inputShape(fc);
  const recs = [...new Set(items.map((i) => i.rec))].filter((_, i) => i % stride === 0);
  const results: SongResult[] = [], skipped: string[] = [];
  let done = 0;
  for (const rec of recs) {
    if (hooks.signal.aborted) return { cancelled: true as const, results, skipped };
    const trainItems = items.filter((i) => i.rec !== rec), test = items.filter((i) => i.rec === rec);
    if (new Set(trainItems.map((i) => i.y)).size < K) { skipped.push(rec); hooks.onFold(++done, recs.length, rec, null); continue; }
    const model = await train({ train: trainItems, val: [] }, labels, fc, cfg, { onEpoch: () => {}, signal: hooks.signal });
    if (!model) return { cancelled: true as const, results, skipped };
    const probs = predictFeatures(model, test.map((t) => t.x), [shape[0], shape[1]]);
    model.dispose();
    const mean = new Array(K).fill(0);
    probs.forEach((p) => p.forEach((v, i) => (mean[i] += v / probs.length)));
    const pred = mean.indexOf(Math.max(...mean));
    results.push({ rec, truth: test[0].y, pred });
    hooks.onFold(++done, recs.length, rec, pred === test[0].y);
  }
  return { cancelled: false as const, results, skipped };
}
