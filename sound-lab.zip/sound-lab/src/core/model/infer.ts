import type * as tf from '@tensorflow/tfjs';
import { extractWindow, splitWindows } from '../audio/features';
import { predictFeatures } from './cnn';
import type { ModelMeta } from '../types';

// Same extractWindow() as training, so features are identical by construction.
export function predictRecording(model: tf.LayersModel, meta: ModelMeta, wav16k: Float32Array) {
  const feats = splitWindows(wav16k, meta.features).map((w) => extractWindow(w, meta.features));
  const probs = predictFeatures(model, feats.map((f) => f.data), [meta.inputShape[0], meta.inputShape[1]]);
  const mean = new Float32Array(meta.labels.length);
  probs.forEach((p) => p.forEach((v, i) => (mean[i] += v / probs.length)));
  return { scores: mean, silent: feats.every((f) => f.silent), clipped: feats.some((f) => f.clipped) };
}
export const top = (s: Float32Array) => s.indexOf(Math.max(...s));
