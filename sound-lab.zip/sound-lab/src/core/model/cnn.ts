import * as tf from '@tensorflow/tfjs';

export function buildModel(numClasses: number, shape: [number, number, number], dropout = 0.3, seed = 1, filters = [8, 16, 32]) {
  if (numClasses < 2) throw new Error('Need at least 2 classes');
  const m = tf.sequential();
  filters.forEach((f, i) => {
    m.add(tf.layers.conv2d({
      filters: f, kernelSize: 3, padding: 'same', useBias: false,
      kernelInitializer: tf.initializers.glorotUniform({ seed: seed + i }),
      ...(i === 0 ? { inputShape: shape } : {}),
    }));
    m.add(tf.layers.batchNormalization());
    m.add(tf.layers.activation({ activation: 'relu' }));
    m.add(tf.layers.maxPooling2d({ poolSize: 2 }));
  });
  m.add(tf.layers.globalAveragePooling2d({}));
  m.add(tf.layers.dropout({ rate: dropout, seed }));
  m.add(tf.layers.dense({ units: numClasses, activation: 'softmax', kernelInitializer: tf.initializers.glorotUniform({ seed: seed + 99 }) }));
  return m;
}

export function predictFeatures(model: tf.LayersModel, xs: Float32Array[], shape: [number, number], batch = 64): Float32Array[] {
  const out: Float32Array[] = [];
  for (let i = 0; i < xs.length; i += batch) {
    const chunk = xs.slice(i, i + batch);
    const r = tf.tidy(() => {
      const flat = new Float32Array(chunk.length * shape[0] * shape[1]);
      chunk.forEach((x, j) => flat.set(x, j * x.length));
      return model.predict(tf.tensor4d(flat, [chunk.length, shape[0], shape[1], 1])) as tf.Tensor;
    });
    const d = r.dataSync() as Float32Array; r.dispose();
    const k = d.length / chunk.length;
    for (let j = 0; j < chunk.length; j++) out.push(d.slice(j * k, (j + 1) * k));
  }
  return out;
}
