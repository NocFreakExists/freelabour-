import type { FeatureConfig } from './audio/features';
export interface ModelMeta {
  schemaVersion: 1;
  name: string;
  version: number;
  labels: string[];
  sampleRate: number;
  windowSec: number;
  hopSec: number;
  features: FeatureConfig;
  normalization: 'peak' | 'rms';
  architecture: string;
  inputShape: [number, number, number];
  trainConfig: Record<string, unknown>;
  metrics: Record<string, unknown>;
  tfjsVersion: string;
  exportDate: string;
}
