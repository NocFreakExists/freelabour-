import './style.css';
import { verifyOffline, clearCache } from './offline/register';
type Kid = Node | string | null | undefined | false;
// Strings become text nodes (never HTML), so user-supplied names are always escaped.
export function h<K extends keyof HTMLElementTagNameMap>(tag: K, props: Record<string, any> = {}, ...kids: Kid[]): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k.startsWith('on')) e.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'class') e.className = v; else if (k === 'value') (e as any).value = v; else e.setAttribute(k, String(v));
  }
  for (const c of kids) if (c) e.append(c);
  return e;
}
export function shell(title: string, body: Kid[]): void {
  const status = h('span', { class: 'pill', role: 'status' }, 'Checking offline status…');
  void verifyOffline().then((r) => (status.textContent = r.text));
  const nav = h('nav', {}, h('a', { href: '/' }, 'Home'), h('a', { href: '/trainer/' }, 'Trainer'), h('a', { href: '/lab/' }, 'Lab'), h('a', { href: '/listen/' }, 'Listener'));
  const foot = h('footer', {}, status, h('button', { onClick: async () => {
    if (confirm('Clear cached app files? Your projects and models are NOT deleted, but you must be online to reload the app.')) { await clearCache(); location.reload(); } } }, 'Clear app cache'),
    h('p', {}, 'Privacy: everything stays on this device. Scores are not calibrated probabilities.'));
  document.getElementById('app')!.replaceChildren(h('header', {}, h('h1', {}, title), nav), h('main', {}, ...body), foot);
}
export function download(bytes: Uint8Array | Blob, name: string) {
  const a = h('a', { href: URL.createObjectURL(bytes instanceof Blob ? bytes : new Blob([bytes as BlobPart])), download: name });
  a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
export const bytesOf = async (f: File) => new Uint8Array(await f.arrayBuffer());
