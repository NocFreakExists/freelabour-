// ONE shared feature pipeline. Training, Lab and Listener all call extractWindow().
export interface FeatureConfig {
  sampleRate: number; windowSec: number; hopSec: number;
  fftSize: number; hopLength: number; nMels: number;
  fMin: number; fMax: number; normalize: 'peak' | 'rms'; silenceRms: number;
}
export const DEFAULT_CONFIG: FeatureConfig = {
  sampleRate: 16000, windowSec: 1, hopSec: 0.5, fftSize: 512, hopLength: 160,
  nMels: 64, fMin: 50, fMax: 8000, normalize: 'peak', silenceRms: 1e-3,
};

export function windowSamples(c: FeatureConfig) { return Math.round(c.sampleRate * c.windowSec); }
export function numFrames(c: FeatureConfig) { return 1 + Math.floor((windowSamples(c) - c.fftSize) / c.hopLength); }
export function inputShape(c: FeatureConfig): [number, number, number] { return [numFrames(c), c.nMels, 1]; }

export function toMono(channels: Float32Array[]): Float32Array {
  if (channels.length === 1) return channels[0];
  const out = new Float32Array(channels[0].length);
  for (const ch of channels) for (let i = 0; i < out.length; i++) out[i] += ch[i] / channels.length;
  return out;
}

// Box-average when downsampling (cheap anti-alias), linear interpolation otherwise.
export function resample(x: Float32Array, from: number, to: number): Float32Array {
  if (from === to) return x;
  const n = Math.floor((x.length * to) / from);
  const out = new Float32Array(n);
  const ratio = from / to;
  const w = Math.max(1, Math.round(ratio));
  for (let i = 0; i < n; i++) {
    const pos = i * ratio;
    if (ratio > 1) {
      const s = Math.floor(pos); let sum = 0, cnt = 0;
      for (let k = s; k < Math.min(s + w, x.length); k++) { sum += x[k]; cnt++; }
      out[i] = cnt ? sum / cnt : 0;
    } else {
      const i0 = Math.floor(pos), i1 = Math.min(i0 + 1, x.length - 1), f = pos - i0;
      out[i] = x[i0] * (1 - f) + x[i1] * f;
    }
  }
  return out;
}

export function splitWindows(x: Float32Array, c: FeatureConfig): Float32Array[] {
  const len = windowSamples(c), hop = Math.round(c.sampleRate * c.hopSec);
  if (hop <= 0) throw new Error('hopSec must be > 0');
  if (x.length < len) { const p = new Float32Array(len); p.set(x); return [p]; }
  const out: Float32Array[] = [];
  for (let s = 0; s + len <= x.length; s += hop) out.push(x.slice(s, s + len));
  return out;
}

export function fft(re: Float64Array, im: Float64Array) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (-2 * Math.PI) / len;
    for (let i = 0; i < n; i += len) {
      for (let k = 0; k < len / 2; k++) {
        const wr = Math.cos(ang * k), wi = Math.sin(ang * k);
        const a = i + k, b = a + len / 2;
        const tr = re[b] * wr - im[b] * wi, ti = re[b] * wi + im[b] * wr;
        re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
      }
    }
  }
}

const hz2mel = (f: number) => 2595 * Math.log10(1 + f / 700);
const mel2hz = (m: number) => 700 * (10 ** (m / 2595) - 1);
const fbCache = new Map<string, Float64Array[]>();
function melBank(c: FeatureConfig): Float64Array[] {
  const key = [c.sampleRate, c.fftSize, c.nMels, c.fMin, c.fMax].join('|');
  const hit = fbCache.get(key); if (hit) return hit;
  const bins = c.fftSize / 2 + 1;
  const pts = Array.from({ length: c.nMels + 2 }, (_, i) =>
    mel2hz(hz2mel(c.fMin) + ((hz2mel(c.fMax) - hz2mel(c.fMin)) * i) / (c.nMels + 1)));
  const binHz = c.sampleRate / c.fftSize;
  const bank: Float64Array[] = [];
  for (let m = 1; m <= c.nMels; m++) {
    const f = new Float64Array(bins);
    for (let b = 0; b < bins; b++) {
      const hz = b * binHz;
      if (hz >= pts[m - 1] && hz <= pts[m]) f[b] = (hz - pts[m - 1]) / (pts[m] - pts[m - 1]);
      else if (hz > pts[m] && hz <= pts[m + 1]) f[b] = (pts[m + 1] - hz) / (pts[m + 1] - pts[m]);
    }
    bank.push(f);
  }
  fbCache.set(key, bank);
  return bank;
}

export interface WindowFeatures { data: Float32Array; frames: number; silent: boolean; clipped: boolean; }

export function extractWindow(win: Float32Array, c: FeatureConfig): WindowFeatures {
  if (win.length !== windowSamples(c)) throw new Error(`Window has ${win.length} samples, expected ${windowSamples(c)}`);
  let peak = 0, sq = 0;
  for (let i = 0; i < win.length; i++) { const a = Math.abs(win[i]); if (a > peak) peak = a; sq += win[i] * win[i]; }
  const rms = Math.sqrt(sq / win.length);
  const silent = rms < c.silenceRms, clipped = peak >= 0.999;
  const x = new Float32Array(win.length);
  if (!silent) {
    const g = c.normalize === 'peak' ? 1 / peak : 0.1 / rms;
    for (let i = 0; i < x.length; i++) x[i] = Math.max(-1, Math.min(1, win[i] * g));
  }
  const frames = numFrames(c), bank = melBank(c), bins = c.fftSize / 2 + 1;
  const hann = new Float64Array(c.fftSize).map((_, i) => 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / c.fftSize));
  const out = new Float32Array(frames * c.nMels);
  const re = new Float64Array(c.fftSize), im = new Float64Array(c.fftSize), pw = new Float64Array(bins);
  for (let f = 0; f < frames; f++) {
    const s = f * c.hopLength;
    for (let i = 0; i < c.fftSize; i++) { re[i] = x[s + i] * hann[i]; im[i] = 0; }
    fft(re, im);
    for (let b = 0; b < bins; b++) pw[b] = re[b] * re[b] + im[b] * im[b];
    for (let m = 0; m < c.nMels; m++) {
      let e = 0; const fl = bank[m];
      for (let b = 0; b < bins; b++) e += fl[b] * pw[b];
      out[f * c.nMels + m] = Math.log(e + 1e-6);
    }
  }
  if (out.some((v) => !Number.isFinite(v))) throw new Error('Invalid feature tensor');
  return { data: out, frames, silent, clipped };
}
