import { FeatureConfig, resample, toMono } from './features';
const MAX_BYTES = 50 * 1024 * 1024, MAX_SEC = 600;

export async function decodeToMono(blob: Blob, c: FeatureConfig, maxSec = 0): Promise<Float32Array> {
  const label = (blob as File).name ?? 'recording';
  if (blob.size === 0) throw new Error(`"${label}" is empty.`);
  if (blob.size > MAX_BYTES) throw new Error(`"${label}" is larger than 50 MB.`);
  const ctx = new AudioContext();
  try {
    const ab = await ctx.decodeAudioData(await blob.arrayBuffer());
    if (ab.duration > MAX_SEC) throw new Error(`"${label}" is longer than 10 minutes.`);
    const chans = Array.from({ length: ab.numberOfChannels }, (_, i) => ab.getChannelData(i));
    const mono = resample(toMono(chans), ab.sampleRate, c.sampleRate);
    const cap = Math.round(maxSec * c.sampleRate);
    if (maxSec > 0 && mono.length > cap) { const s = Math.floor((mono.length - cap) / 2); return mono.slice(s, s + cap); } // centre segment
    return mono;
  } catch (e) {
    if (e instanceof Error && e.message.startsWith('"')) throw e;
    throw new Error(`Could not decode "${label}": unsupported or corrupt. Convert it to 16-bit PCM WAV and try again.`);
  } finally { void ctx.close(); }
}
