const NAME = 'soundlab', VERSION = 1;
export type Store = 'projects' | 'samples' | 'models';
let dbp: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  return (dbp ??= new Promise((res, rej) => {
    const r = indexedDB.open(NAME, VERSION);
    r.onupgradeneeded = () => {
      for (const s of ['projects', 'samples', 'models']) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s, { keyPath: 'id' });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  }));
}
function friendly(e: unknown): Error {
  const n = (e as DOMException)?.name;
  if (n === 'QuotaExceededError') return new Error('Storage is full. Export or delete data, then retry. Nothing was changed.');
  return e instanceof Error ? e : new Error(String(e));
}
// Each write is one IndexedDB transaction: it commits fully or not at all (interrupted-write safe).
async function run<T>(store: Store, mode: IDBTransactionMode, f: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise<T>((res, rej) => {
    const tx = db.transaction(store, mode); let out: T;
    const req = f(tx.objectStore(store));
    req.onsuccess = () => (out = req.result);
    tx.oncomplete = () => res(out);
    tx.onerror = tx.onabort = () => rej(friendly(tx.error));
  });
}
export const put = <T extends { id: string }>(s: Store, v: T) => run(s, 'readwrite', (o) => o.put(v));
export const get = <T>(s: Store, id: string) => run<T | undefined>(s, 'readonly', (o) => o.get(id));
export const getAll = <T>(s: Store) => run<T[]>(s, 'readonly', (o) => o.getAll());
export const del = (s: Store, id: string) => run(s, 'readwrite', (o) => o.delete(id));

export async function persist(): Promise<string> {
  const ok = (await navigator.storage?.persist?.()) ?? false;
  return ok ? 'Persistent storage granted.' : 'Storage may be evicted by the browser (common on iOS/Safari). Export backups regularly.';
}
export async function usage(): Promise<string> {
  const e = await navigator.storage?.estimate?.();
  return e ? `${((e.usage ?? 0) / 1e6).toFixed(1)} MB used of about ${((e.quota ?? 0) / 1e6).toFixed(0)} MB` : 'Usage unavailable';
}
