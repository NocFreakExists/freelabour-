import * as tf from '@tensorflow/tfjs';
import { zipSync, unzipSync, strToU8, strFromU8 } from 'fflate';
import type { ModelMeta } from '../types';

const MAX_ZIP = 100 * 1024 * 1024, MAX_FILE = 100 * 1024 * 1024;
const ALLOWED = new Set(['model.json', 'weights.bin', 'metadata.json', 'checksums.json']);

async function sha256(b: Uint8Array): Promise<string> {
  const d = await crypto.subtle.digest('SHA-256', b as BufferSource);
  return [...new Uint8Array(d)].map((x) => x.toString(16).padStart(2, '0')).join('');
}

export async function exportPackage(model: tf.LayersModel, meta: ModelMeta): Promise<Uint8Array> {
  let art!: tf.io.ModelArtifacts;
  await model.save(tf.io.withSaveHandler(async (a) => {
    art = a;
    return { modelArtifactsInfo: { dateSaved: new Date(), modelTopologyType: 'JSON' as const } };
  }));
  const weights = new Uint8Array(art.weightData as ArrayBuffer); // single shard
  const modelJson = { format: 'layers-model', generatedBy: 'sound-lab', modelTopology: art.modelTopology,
    weightsManifest: [{ paths: ['weights.bin'], weights: art.weightSpecs }] };
  const files: Record<string, Uint8Array> = {
    'model.json': strToU8(JSON.stringify(modelJson)),
    'weights.bin': weights,
    'metadata.json': strToU8(JSON.stringify(meta)),
  };
  const sums: Record<string, string> = {};
  for (const [k, v] of Object.entries(files)) sums[k] = await sha256(v);
  files['checksums.json'] = strToU8(JSON.stringify(sums));
  return zipSync(files);
}

function validateMeta(m: any): ModelMeta {
  const bad = (why: string) => { throw new Error(`Invalid model package: ${why}`); };
  if (!m || typeof m !== 'object') bad('metadata.json is not an object');
  if (m.schemaVersion !== 1) bad(`unsupported schemaVersion ${m.schemaVersion} (this app reads 1)`);
  if (!Array.isArray(m.labels) || m.labels.length < 2 || m.labels.length > 200 ||
      m.labels.some((l: unknown) => typeof l !== 'string' || l.length === 0 || l.length > 100)) bad('labels must be 2-200 non-empty strings');
  if (typeof m.name !== 'string' || m.name.length > 200) bad('name missing or too long');
  for (const k of ['sampleRate', 'windowSec', 'hopSec']) if (typeof m[k] !== 'number' || !(m[k] > 0)) bad(`${k} must be a positive number`);
  const f = m.features;
  if (!f || ['fftSize', 'hopLength', 'nMels', 'fMin', 'fMax', 'sampleRate', 'windowSec', 'hopSec'].some((k) => typeof f[k] !== 'number')) bad('features incomplete');
  if (f.normalize !== 'peak' && f.normalize !== 'rms') bad('features.normalize must be peak or rms');
  if (f.nMels > 256 || f.fftSize > 8192 || (f.fftSize & (f.fftSize - 1)) !== 0) bad('feature sizes out of range');
  if (!Array.isArray(m.inputShape) || m.inputShape.length !== 3) bad('inputShape invalid');
  return m as ModelMeta;
}

export async function importPackage(bytes: Uint8Array): Promise<{ model: tf.LayersModel; meta: ModelMeta }> {
  if (bytes.length > MAX_ZIP) throw new Error('Package is larger than 100 MB.');
  let files: Record<string, Uint8Array>;
  try { files = unzipSync(bytes, { filter: (f) => f.originalSize <= MAX_FILE }); }
  catch { throw new Error('Not a valid zip archive.'); }
  for (const k of Object.keys(files)) if (!ALLOWED.has(k)) throw new Error(`Unexpected file in package: ${k.slice(0, 60)}`);
  for (const k of ALLOWED) if (!files[k]) throw new Error(`Package is missing ${k}.`);
  let sums: Record<string, string>;
  try { sums = JSON.parse(strFromU8(files['checksums.json'])); } catch { throw new Error('checksums.json is not valid JSON.'); }
  for (const k of ['model.json', 'weights.bin', 'metadata.json'])
    if (sums[k] !== (await sha256(files[k]))) throw new Error(`Checksum mismatch for ${k}: the package is corrupted or was modified.`);
  let meta: ModelMeta, mj: any;
  try { meta = validateMeta(JSON.parse(strFromU8(files['metadata.json']))); } catch (e) {
    if (e instanceof SyntaxError) throw new Error('metadata.json is not valid JSON.'); throw e; }
  try { mj = JSON.parse(strFromU8(files['model.json'])); } catch { throw new Error('model.json is not valid JSON.'); }
  const specs = mj?.weightsManifest?.[0]?.weights;
  if (!mj?.modelTopology || !Array.isArray(specs)) throw new Error('model.json has no topology or weight specs.');
  const wd = files['weights.bin'];
  const weightData = wd.buffer.slice(wd.byteOffset, wd.byteOffset + wd.byteLength) as ArrayBuffer;
  let model: tf.LayersModel;
  try { model = await tf.loadLayersModel(tf.io.fromMemory({ modelTopology: mj.modelTopology, weightSpecs: specs, weightData })); }
  catch (e) { throw new Error(`Model could not be loaded (incompatible TF.js version or corrupt weights): ${(e as Error).message}`); }
  const out = model.outputs[0].shape;
  if (out[out.length - 1] !== meta.labels.length) { model.dispose(); throw new Error('Label count does not match model output size.'); }
  return { model, meta };
}
