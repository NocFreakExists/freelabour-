// Registers the service worker (production only) and verifies the cache for real.
export async function registerSW(): Promise<void> {
  if (!('serviceWorker' in navigator) || !import.meta.env.PROD) return;
  await navigator.serviceWorker.register('/sw.js');
}
export async function verifyOffline(): Promise<{ ready: boolean; missing: string[]; text: string }> {
  try {
    const pc = await (await fetch('/precache.json', { cache: 'no-store' })).json() as { assets: string[] };
    const missing: string[] = [];
    for (const a of pc.assets) if (!(await caches.match(a, { ignoreSearch: true }))) missing.push(a);
    return { ready: missing.length === 0, missing, text: missing.length ? `Not offline-ready: ${missing.length} files not cached yet.` : 'Offline-ready: all files are cached.' };
  } catch { return { ready: false, missing: [], text: 'Offline status unknown (dev mode or first load).' }; }
}
export async function clearCache() { (await navigator.serviceWorker.getRegistration())?.active?.postMessage('CLEAR_CACHE'); }
void registerSW();
