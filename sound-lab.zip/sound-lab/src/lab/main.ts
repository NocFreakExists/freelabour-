import { h, shell, bytesOf } from '../core/ui';
import { initTF, tf } from '../core/tf';
import { getAll, put } from '../core/storage/db';
import { importPackage } from '../core/package/pkg';
import { decodeToMono } from '../core/audio/decode';
import { predictRecording, top } from '../core/model/infer';
import type { ModelMeta } from '../core/types';

// The Lab only READS the model library; it never touches Trainer projects or samples.
let cur: { model: tf.LayersModel; meta: ModelMeta } | null = null;
let threshold = 0.6, info = '';
interface Row { file: string; scores: Float32Array; truth: number; note: string }
let history: Row[] = [];
let library: { id: string; name: string; version: number; bytes: Uint8Array }[] = [];

const guard = async (f: () => Promise<void>) => { try { await f(); info = ''; } catch (e) { info = (e as Error).message; } render(); };
async function use(bytes: Uint8Array) { await initTF(); cur?.model.dispose(); cur = await importPackage(bytes); history = []; }

async function test(files: FileList) {
  if (!cur) throw new Error('Choose a model first.');
  for (const f of files) {
    try {
      const wav = await decodeToMono(f, cur.meta.features);
      const r = predictRecording(cur.model, cur.meta, wav);
      history.unshift({ file: f.name, scores: r.scores, truth: -1, note: (r.silent ? 'silence ' : '') + (r.clipped ? 'clipped' : '') });
    } catch (e) { history.unshift({ file: f.name, scores: new Float32Array(0), truth: -1, note: (e as Error).message }); }
  }
}
function render() {
  const m = cur?.meta;
  const labelled = history.filter((r) => r.truth >= 0 && r.scores.length);
  const acc = labelled.length ? labelled.filter((r) => top(r.scores) === r.truth).length / labelled.length : null;
  shell('Model Test Lab', [
    info && h('p', { role: 'alert', class: 'warn' }, info),
    h('div', { class: 'card' }, h('h2', {}, '1. Choose a model'),
      h('div', { class: 'row' },
        h('select', { 'aria-label': 'Model library', onChange: (e: Event) => { const v = library.find((l) => l.id === (e.target as HTMLSelectElement).value); if (v) void guard(() => use(v.bytes)); } },
          h('option', { value: '' }, 'Pick from library…'), ...library.map((l) => h('option', { value: l.id }, `${l.name} v${l.version}`))),
        h('input', { type: 'file', accept: '.zip', 'aria-label': 'Import model package', onChange: (e: Event) => guard(async () => {
          const f = (e.target as HTMLInputElement).files![0]; if (!f) return;
          const bytes = await bytesOf(f); await use(bytes);
          if (confirm('Also save this model to your library?')) await put('models', { id: crypto.randomUUID(), name: cur!.meta.name, version: cur!.meta.version, bytes, createdAt: new Date().toISOString() });
          library = await getAll('models'); }) }))),
    m && h('div', { class: 'card' }, h('h3', {}, 'Model info'),
      h('p', {}, `${m.name} v${m.version} · classes: ${m.labels.join(', ')}`),
      h('p', {}, `${m.sampleRate} Hz · window ${m.windowSec}s · hop ${m.hopSec}s · ${m.features.nMels} mel bands · ${m.normalization} normalisation · TF.js ${m.tfjsVersion}`),
      h('p', {}, `Training summary: ${JSON.stringify(m.metrics)}`),
      h('p', {}, 'Scores are model confidence values, not calibrated probabilities. A 90% score does not mean it is right 90% of the time.')),
    h('div', { class: 'card' }, h('h2', {}, '2. Test audio'),
      h('label', {}, `Uncertain below ${(threshold * 100).toFixed(0)}% `, h('input', { type: 'range', min: 0, max: 1, step: 0.05, value: threshold, onInput: (e: Event) => { threshold = +(e.target as HTMLInputElement).value; render(); } })),
      h('input', { type: 'file', accept: 'audio/*', multiple: '', 'aria-label': 'Test audio files', onChange: (e: Event) => guard(() => test((e.target as HTMLInputElement).files!)) })),
    acc !== null && h('p', { class: 'pill' }, `Accuracy on ${labelled.length} labelled files: ${(acc * 100).toFixed(1)}%`),
    ...history.map((r, idx) => {
      if (!r.scores.length) return h('div', { class: 'card warn' }, `${r.file}: ${r.note}`);
      const t = top(r.scores), sure = r.scores[t] >= threshold && !r.note.startsWith('silence');
      return h('div', { class: 'card' }, h('b', {}, r.file), h('div', { class: 'big' }, r.note.startsWith('silence') ? 'Silence' : sure ? m!.labels[t] : 'Uncertain'),
        ...m!.labels.map((l, i) => h('div', {}, `${l} ${(r.scores[i] * 100).toFixed(1)}%`, h('div', { class: 'bar' }, h('div', { style: `width:${r.scores[i] * 100}%` })))),
        h('label', {}, 'True label: ', h('select', { onChange: (e: Event) => { r.truth = +(e.target as HTMLSelectElement).value; render(); } },
          h('option', { value: -1 }, 'unknown'), ...m!.labels.map((l, i) => h('option', { value: i }, l)))), r.note && h('span', { class: 'warn' }, r.note));
    }),
    labelled.length > 0 && m && h('table', {}, h('tr', {}, h('th', {}, 'true \\ predicted'), ...m.labels.map((l) => h('th', {}, l))),
      ...m.labels.map((l, i) => h('tr', {}, h('th', {}, l), ...m.labels.map((_, j) => h('td', {}, String(labelled.filter((r) => r.truth === i && top(r.scores) === j).length)))))),
  ]);
}
void (async () => { library = await getAll('models'); render(); })();
