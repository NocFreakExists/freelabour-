import { h, shell, download } from '../core/ui';
import { initTF, tf } from '../core/tf';
import { put, getAll, del, persist, usage } from '../core/storage/db';
import { DEFAULT_CONFIG, extractWindow, splitWindows, inputShape } from '../core/audio/features';
import { decodeToMono } from '../core/audio/decode';
import { DEFAULT_TRAIN, Item, TrainConfig, evaluate, splitByRecording, train } from '../core/model/train';
import { exportPackage } from '../core/package/pkg';
import { generateToneNoise, encodeWav } from '../core/synth';
import type { ModelMeta } from '../core/types';

interface Cls { id: string; name: string }
interface Sample { id: string; classId: string; name: string; blob: Blob }
interface Stored { id: string; name: string; bytes: Uint8Array; createdAt: string; version: number }
const fc = DEFAULT_CONFIG;
let classes: Cls[] = [], samples: Sample[] = [], trained: { model: any; meta: ModelMeta } | null = null;
let abort: AbortController | null = null, logLines: string[] = [], resultNode: Node | null = null, info = '';
const uid = () => crypto.randomUUID();

async function load() {
  classes = ((await getAll<any>('projects')).find((p) => p.id === 'default')?.classes) ?? [];
  samples = await getAll<Sample>('samples');
}
const saveClasses = () => put('projects', { id: 'default', classes });
const guard = async (f: () => Promise<void>) => { try { await f(); } catch (e) { info = (e as Error).message; } render(); };

function log(s: string) { logLines.push(s); const p = document.querySelector('pre.log'); if (p) { p.textContent = logLines.join('\n'); p.scrollTop = p.scrollHeight; } }

async function addFiles(c: Cls, files: FileList | File[]) {
  for (const f of files) {
    await decodeToMono(f, fc); // validate now so bad files are rejected with a clear message
    await put('samples', { id: uid(), classId: c.id, name: f.name, blob: f });
  }
  samples = await getAll<Sample>('samples');
}
async function record(c: Cls) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const rec = new MediaRecorder(stream), parts: Blob[] = [];
  rec.ondataavailable = (e) => parts.push(e.data);
  rec.start(); await new Promise((r) => setTimeout(r, 3000)); rec.stop();
  await new Promise((r) => (rec.onstop = r));
  stream.getTracks().forEach((t) => t.stop()); // release mic
  const b = new File(parts, `recording-${Date.now()}`, { type: rec.mimeType });
  await addFiles(c, [b]);
}
async function loadSynthetic() {
  classes = [{ id: uid(), name: 'tone' }, { id: uid(), name: 'noise' }];
  for (const s of await getAll<Sample>('samples')) await del('samples', s.id);
  for (const clip of generateToneNoise(12, 3, fc.sampleRate, 1)) {
    const c = classes.find((k) => k.name === clip.label)!;
    await put('samples', { id: uid(), classId: c.id, name: clip.name, blob: new File([encodeWav(clip.data, fc.sampleRate) as BlobPart], clip.name, { type: 'audio/wav' }) });
  }
  await saveClasses(); samples = await getAll<Sample>('samples');
}

async function run(cfg: TrainConfig) {
  abort = new AbortController(); logLines = []; resultNode = null; info = ''; render();
  const backend = await initTF(); log(`Backend: ${backend}`);
  const items: Item[] = [];
  for (const s of samples) {
    const y = classes.findIndex((c) => c.id === s.classId); if (y < 0) continue;
    for (const w of splitWindows(await decodeToMono(s.blob, fc), fc)) items.push({ x: extractWindow(w, fc).data, w, y, rec: s.id });
  }
  if (classes.length < 2) throw new Error('Add at least 2 classes.');
  classes.forEach((c, i) => { if (!items.some((x) => x.y === i)) throw new Error(`Class "${c.name}" has no samples.`); });
  const split = splitByRecording(items, classes.length, 0.2, 0.2, cfg.seed);
  if (!split.hasValidation) log('WARNING: too few recordings per class for a validation set; early stopping is off.');
  if (!split.hasIndependentTest) log('WARNING: no independent test set (need 3+ recordings per class). Final numbers below use TRAINING data and are optimistic.');
  log(`Windows: train ${split.train.length}, val ${split.val.length}, test ${split.test.length}`);
  const model = await train(split, classes.map((c) => c.name), fc, cfg, {
    signal: abort.signal,
    onEpoch: (l) => log(`epoch ${l.epoch} loss ${l.loss.toFixed(3)} acc ${l.acc.toFixed(3)}` + (l.valLoss !== undefined ? ` | val_loss ${l.valLoss.toFixed(3)} val_acc ${l.valAcc?.toFixed(3)}` : '') + ` | ${l.seconds.toFixed(1)}s`),
  });
  if (!model) { log('Cancelled. Previous model untouched.'); return; }
  const held = split.hasIndependentTest ? split.test : split.train;
  const m = evaluate(model, held, classes.length, fc);
  const meta: ModelMeta = { schemaVersion: 1, name: 'My sound model', version: 1, labels: classes.map((c) => c.name),
    sampleRate: fc.sampleRate, windowSec: fc.windowSec, hopSec: fc.hopSec, features: fc, normalization: fc.normalize,
    architecture: 'cnn 3x(conv3x3-bn-relu-maxpool) gap dropout dense-softmax', inputShape: inputShape(fc),
    trainConfig: { ...cfg }, metrics: { accuracy: m.accuracy, evaluatedOn: split.hasIndependentTest ? 'held-out test recordings' : 'training data (no independent test set)', n: m.n },
    tfjsVersion: tf.version.tfjs, exportDate: new Date().toISOString() };
  trained?.model.dispose(); trained = { model, meta };
  resultNode = h('div', { class: 'card' },
    h('h3', {}, split.hasIndependentTest ? 'Held-out test results' : 'Results on TRAINING data (not independent)'),
    h('p', {}, `Accuracy ${(m.accuracy * 100).toFixed(1)}% on ${m.n} windows`),
    h('table', {}, h('tr', {}, h('th', {}, 'class'), h('th', {}, 'precision'), h('th', {}, 'recall'), h('th', {}, 'F1'), h('th', {}, 'n')),
      ...m.perClass.map((p, i) => h('tr', {}, h('td', {}, classes[i].name), h('td', {}, p.precision.toFixed(2)), h('td', {}, p.recall.toFixed(2)), h('td', {}, p.f1.toFixed(2)), h('td', {}, String(p.support))))),
    h('p', {}, 'Confusion matrix (rows = true, columns = predicted)'),
    h('table', {}, ...m.confusion.map((r, i) => h('tr', {}, h('th', {}, classes[i].name), ...r.map((v) => h('td', {}, String(v)))))));
}

async function publish(download_: boolean) {
  if (!trained) return;
  const name = prompt('Model name?', trained.meta.name)?.slice(0, 100); if (!name) return;
  const prev = (await getAll<Stored>('models')).filter((m) => m.name === name);
  trained.meta.name = name; trained.meta.version = prev.length + 1;
  const bytes = await exportPackage(trained.model, trained.meta);
  if (download_) return download(bytes, `${name}-v${trained.meta.version}.zip`);
  await put('models', { id: uid(), name, bytes, createdAt: new Date().toISOString(), version: trained.meta.version });
  info = `Published "${name}" v${trained.meta.version} to the local library (visible in Lab and Listener).`;
}

function render() {
  const cfg = { ...DEFAULT_TRAIN };
  const training = !!abort && !abort.signal.aborted && logLines.length > 0 && !resultNode && !info;
  shell('Trainer Studio', [
    h('p', {}, h('b', {}, 'Training'), ' teaches a model from your labelled sounds (slow, done here). ', h('b', {}, 'Inference'), ' uses a finished model to label new sounds (fast, done in Lab/Listener).'),
    info && h('p', { role: 'alert', class: 'warn' }, info),
    h('div', { class: 'row' },
      h('button', { onClick: () => guard(loadSynthetic) }, 'Load synthetic tone-vs-noise project'),
      h('button', { onClick: () => { const n = prompt('Class name?')?.slice(0, 60); if (n) guard(async () => { classes.push({ id: uid(), name: n }); await saveClasses(); }); } }, 'Add class')),
    ...classes.map((c) => {
      const mine = samples.filter((s) => s.classId === c.id);
      return h('section', { class: 'card', 'aria-label': `Class ${c.name}` },
        h('h3', {}, `${c.name} (${mine.length} samples)`),
        mine.length === 0 && h('p', { class: 'warn' }, 'Empty class: add samples before training.'),
        h('div', { class: 'row' },
          h('input', { type: 'file', accept: 'audio/*', multiple: '', 'aria-label': `Add audio files to ${c.name}`, onChange: (e: Event) => guard(() => addFiles(c, (e.target as HTMLInputElement).files!)) }),
          h('button', { onClick: () => guard(() => record(c)) }, 'Record 3 s'),
          h('button', { onClick: () => confirm(`Delete class "${c.name}" and its samples?`) && guard(async () => {
            for (const s of mine) await del('samples', s.id); classes = classes.filter((k) => k !== c); await saveClasses(); samples = await getAll<Sample>('samples'); }) }, 'Delete class')),
        ...mine.slice(0, 50).map((s) => h('div', { class: 'row' }, h('span', {}, s.name),
          h('button', { onClick: () => void new Audio(URL.createObjectURL(s.blob)).play() }, 'Play'),
          h('button', { onClick: () => guard(async () => { await del('samples', s.id); samples = await getAll<Sample>('samples'); }) }, 'Delete'))));
    }),
    h('div', { class: 'row' },
      h('button', { class: 'primary', onClick: () => guard(() => run(cfg)) }, 'Train'),
      h('button', { onClick: () => abort?.abort() }, 'Cancel')),
    h('pre', { class: 'log', 'aria-live': 'polite' }, logLines.join('\n')),
    resultNode,
    trained && h('div', { class: 'row' }, h('button', { class: 'primary', onClick: () => guard(() => publish(false)) }, 'Publish to library'),
      h('button', { onClick: () => guard(() => publish(true)) }, 'Export model .zip')),
    h('p', { class: 'pill' }, training ? 'Training…' : 'Idle'),
  ]);
}
void (async () => { await load(); render(); info = await persist(); render(); const u = await usage(); info += ' ' + u; render(); })();
