import { h, shell } from '../core/ui';
import { initTF, tf } from '../core/tf';
import { getAll } from '../core/storage/db';
import { importPackage } from '../core/package/pkg';
import { resample, windowSamples, extractWindow } from '../core/audio/features';
import { predictFeatures } from '../core/model/cnn';
import type { ModelMeta } from '../core/types';

// Listener: reads published models only. No dataset or project access, no training.
let lib: { id: string; name: string; version: number; bytes: Uint8Array }[] = [];
let sel = '', cur: { model: tf.LayersModel; meta: ModelMeta } | null = null;
let ctx: AudioContext | null = null, stream: MediaStream | null = null, timer = 0;
let state = 'Tap Listen', conf = 0, threshold = 0.6, info = '', recent: string[] = [];
let smooth: Float32Array | null = null, lastShown = '';

function stop() {
  clearInterval(timer); stream?.getTracks().forEach((t) => t.stop()); void ctx?.close();
  ctx = null; stream = null; state = 'Stopped'; conf = 0; render();
}
async function start() {
  info = '';
  const entry = lib.find((l) => l.id === sel); if (!entry) { info = 'Choose a model first.'; return render(); }
  try {
    await initTF(); cur?.model.dispose(); cur = await importPackage(entry.bytes);
    stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false } });
    ctx = new AudioContext(); await ctx.audioWorklet.addModule('/worklet.js');
    const src = ctx.createMediaStreamSource(stream), node = new AudioWorkletNode(ctx, 'cap');
    const need = Math.ceil(ctx.sampleRate * cur.meta.windowSec), ring = new Float32Array(need);
    node.port.onmessage = (e: MessageEvent<Float32Array>) => { ring.copyWithin(0, e.data.length); ring.set(e.data.slice(-need), need - Math.min(need, e.data.length)); };
    src.connect(node); // not connected to destination: no echo
    const meta = cur.meta, model = cur.model; smooth = null;
    timer = window.setInterval(() => {
      const win = resample(ring, ctx!.sampleRate, meta.sampleRate);
      const fixed = win.length >= windowSamples(meta.features) ? win.slice(0, windowSamples(meta.features)) : null; if (!fixed) return;
      const f = extractWindow(fixed, meta.features);
      if (f.silent) { state = 'Silence'; conf = 0; smooth = null; return render(); }
      const p = predictFeatures(model, [f.data], [meta.inputShape[0], meta.inputShape[1]])[0];
      smooth = smooth ? smooth.map((v, i) => 0.6 * v + 0.4 * p[i]) as Float32Array : p; // temporal smoothing
      const t = smooth.indexOf(Math.max(...smooth)); conf = smooth[t];
      state = conf >= threshold ? meta.labels[t] : 'Uncertain';
      if (state !== lastShown && state !== 'Uncertain') { recent.unshift(`${new Date().toLocaleTimeString()} ${state}`); recent = recent.slice(0, 10); }
      lastShown = state; render();
    }, 250);
    state = 'Listening…'; render();
  } catch (e) { info = (e as Error).message; stop(); }
}
function render() {
  const on = !!ctx;
  shell('Listener', [
    info && h('p', { role: 'alert', class: 'warn' }, info),
    h('select', { 'aria-label': 'Published model', onChange: (e: Event) => (sel = (e.target as HTMLSelectElement).value) },
      h('option', { value: '' }, lib.length ? 'Choose a model…' : 'No published models yet'), ...lib.map((l) => h('option', { value: l.id, ...(l.id === sel ? { selected: '' } : {}) }, `${l.name} v${l.version}`))),
    h('div', { class: 'big', 'aria-live': 'polite' }, state),
    h('div', { class: 'bar', role: 'progressbar', 'aria-valuenow': Math.round(conf * 100), 'aria-valuemin': 0, 'aria-valuemax': 100 }, h('div', { style: `width:${conf * 100}%` })),
    h('p', {}, on ? '🎤 Microphone is ON' : 'Microphone is off'),
    h('button', { class: 'primary', style: 'width:100%;min-height:72px;font-size:24px', onClick: () => (on ? stop() : void start()) }, on ? 'Stop' : 'Listen'),
    h('label', {}, `Uncertain below ${(threshold * 100).toFixed(0)}% `, h('input', { type: 'range', min: 0.2, max: 0.95, step: 0.05, value: threshold, onInput: (e: Event) => (threshold = +(e.target as HTMLInputElement).value) })),
    h('h3', {}, 'Recent detections'), h('ul', {}, ...recent.map((r) => h('li', {}, r))),
  ]);
}
void (async () => { lib = await getAll('models'); render(); })();
